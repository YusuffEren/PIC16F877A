'use client';
import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useClockStore } from '@/store/useClockStore';

interface HwButtonProps {
  label: string;
  btnId: 1 | 2 | 3 | 4;
  className?: string;
}

export const HwButton: React.FC<HwButtonProps> = ({ label, btnId, className = '' }) => {
  const [spark, setSpark] = useState(false);

  const actionMap = {
    1: useClockStore((s) => s.incrementHour),
    2: useClockStore((s) => s.decrementHour),
    3: useClockStore((s) => s.incrementMinute),
    4: useClockStore((s) => s.decrementMinute),
  };

  const setButtonState = useClockStore((s) => s.setButtonState);

  const handlePointerDown = useCallback(() => {
    actionMap[btnId]();
    setSpark(true);
  }, [btnId]);

  const handlePointerUp = useCallback(() => {
    setButtonState(btnId, 0);
    setTimeout(() => setSpark(false), 400);
  }, [btnId]);

  const handlePointerLeave = useCallback(() => {
    setButtonState(btnId, 0);
    setTimeout(() => setSpark(false), 400);
  }, [btnId]);

  return (
    <div className={`hw-buttons relative flex flex-col items-center ${className}`}>
      <motion.button
        className="relative w-full aspect-[4/3] outline-none"
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerLeave}
        whileTap={{ scale: 0.93 }}
        transition={{ type: 'spring', stiffness: 500, damping: 20 }}
      >
        <svg viewBox="0 0 120 90" className="w-full h-full drop-shadow-lg">
          <defs>
            <linearGradient id={`btnBodyGrad${btnId}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#475569" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            <linearGradient id={`btnCapGrad${btnId}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f87171" />
              <stop offset="100%" stopColor="#dc2626" />
            </linearGradient>
            <filter id={`btnShadow${btnId}`}>
              <feDropShadow dx="0" dy="3" stdDeviation="2" floodColor="#000" floodOpacity="0.4" />
            </filter>
          </defs>

          {/* Base housing */}
          <rect x="15" y="35" width="90" height="42" rx="8" fill={`url(#btnBodyGrad${btnId})`} stroke="#334155" strokeWidth="1.5" filter={`url(#btnShadow${btnId})`} />

          {/* Side pins */}
          <rect x="22" y="75" width="6" height="10" rx="2" fill="#94a3b8" />
          <rect x="92" y="75" width="6" height="10" rx="2" fill="#94a3b8" />

          {/* Button cap - 3D cylinder */}
          <rect x="22" y="22" width="76" height="24" rx="6" fill={`url(#btnCapGrad${btnId})`} stroke="#991b1b" strokeWidth="1" />
          <ellipse cx="60" cy="22" rx="38" ry="6" fill="#fca5a5" opacity="0.4" />

          {/* Pressed state inner shadow indication */}
          <rect x="24" y="24" width="72" height="20" rx="4" fill="none" stroke="#7f1d1d" strokeWidth="0.5" opacity="0.5" />
        </svg>

        {/* Electric signal spark traveling from button to PIC */}
        <AnimatePresence>
          {spark && (
            <motion.div
              className="absolute top-1/2 left-1/2 w-3 h-3 rounded-full bg-amber-400 pointer-events-none"
              style={{ boxShadow: '0 0 10px 2px rgba(251,191,36,0.8)' }}
              initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
              animate={{
                x: [0, 30, 60, 90, 120],
                y: [0, -20, -40, -60, -80],
                opacity: [1, 1, 1, 0.6, 0],
                scale: [1, 0.8, 0.6, 0.4, 0.2],
              }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
              exit={{ opacity: 0 }}
            />
          )}
        </AnimatePresence>
      </motion.button>
      <span className="mt-2 text-[10px] text-slate-400 font-mono uppercase tracking-wider">{label}</span>
    </div>
  );
};

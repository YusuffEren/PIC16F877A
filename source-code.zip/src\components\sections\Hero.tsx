'use client';
import React, { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { motion } from 'framer-motion';
import { Breadboard } from '@/components/hardware/Breadboard';
import { Pic16f877a } from '@/components/hardware/Pic16f877a';
import { LcdDisplay } from '@/components/hardware/LcdDisplay';
import { Crystal } from '@/components/hardware/Crystal';
import { HwButton } from '@/components/hardware/HwButton';

export const Hero: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    if (!containerRef.current || !titleRef.current) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'back.out(1.7)' } });

      // Stage 1: Breadboard drops in
      tl.fromTo(
        '.hero-breadboard',
        { opacity: 0, y: -120, scale: 0.85 },
        { opacity: 1, y: 0, scale: 1, duration: 1 }
      )
        // Stage 2: PIC slides from left with snap
        .fromTo(
          '.hero-pic',
          { opacity: 0, x: -140, rotation: -8 },
          { opacity: 1, x: 0, rotation: 0, duration: 0.8, ease: 'elastic.out(1, 0.5)' },
          '-=0.5'
        )
        // Stage 3: Crystal drops from top
        .fromTo(
          '.hero-crystal',
          { opacity: 0, y: -80, scale: 0.7 },
          { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: 'bounce.out' },
          '-=0.4'
        )
        // Stage 4: LCD rises and snaps
        .fromTo(
          '.hero-lcd',
          { opacity: 0, y: 60, scale: 0.9 },
          { opacity: 1, y: 0, scale: 1, duration: 0.9, ease: 'back.out(2)' },
          '-=0.3'
        )
        // Stage 5: Buttons snap in staggered
        .fromTo(
          '.hero-buttons',
          { opacity: 0, x: 100, scale: 0.8 },
          { opacity: 1, x: 0, scale: 1, duration: 0.5, stagger: 0.12, ease: 'back.out(1.4)' },
          '-=0.5'
        )
        // Stage 6: Title characters pop in
        .fromTo(
          '.hero-title-char',
          { opacity: 0, y: 20, scale: 0.8 },
          { opacity: 1, y: 0, scale: 1, duration: 0.04, stagger: 0.03, ease: 'power2.out' },
          '-=0.2'
        )
        // Stage 7: Subtitle fade up
        .fromTo(
          '.hero-subtitle',
          { opacity: 0, y: 15 },
          { opacity: 1, y: 0, duration: 0.6 },
          '-=0.1'
        )
        // Stage 8: LCD backlight boot
        .call(() => setBooted(true), [], '+=0.2');
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const titleText = 'PIC16F877A Dijital Saat';

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center bg-slate-950 overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-cyan-500/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 left-1/4 w-[300px] h-[300px] bg-blue-600/5 rounded-full blur-[100px]" />
      </div>

      <div ref={containerRef} className="relative z-10 w-full max-w-6xl mx-auto px-4 py-12">
        {/* Title */}
        <div className="text-center mb-12">
          <h1
            ref={titleRef}
            className="text-4xl md:text-6xl font-bold text-slate-100 tracking-tight mb-4 whitespace-nowrap"
          >
            {titleText.split('').map((char, i) => (
              <span key={i} className="hero-title-char inline-block" style={{ opacity: 0 }}>
                {char === ' ' ? '\u00A0' : char}
              </span>
            ))}
          </h1>
          <p className="hero-subtitle text-slate-400 text-lg max-w-2xl mx-auto" style={{ opacity: 0 }}>
            Gerçek zamanlı saat sisteminin web tabanlı interaktif simülasyonu.
            Mikrodenetleyici, LCD ekran ve buton kontrollerini tarayıcıda deneyimleyin.
          </p>
        </div>

        {/* Assembly stage */}
        <div className="relative w-full aspect-[2/1] bg-slate-900/40 rounded-2xl border border-slate-800/80 p-6 shadow-2xl backdrop-blur-sm overflow-hidden">
          {/* Grid background */}
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '28px 28px' }} />

          {/* Breadboard */}
          <div className="hero-breadboard absolute inset-4 opacity-0">
            <Breadboard />
          </div>

          {/* PIC placed center-top */}
          <div className="hero-pic absolute left-[38%] top-[10%] w-[12%] h-[52%] opacity-0 z-10">
            <Pic16f877a />
          </div>

          {/* Crystal placed top-right */}
          <div className="hero-crystal absolute right-[16%] top-[8%] w-[24%] h-[18%] opacity-0 z-10">
            <Crystal />
          </div>

          {/* LCD placed middle */}
          <div className="hero-lcd absolute left-[18%] top-[38%] w-[64%] h-[34%] opacity-0 z-20">
            <LcdDisplay />
            {booted && (
              <motion.div
                className="absolute inset-0 rounded-xl pointer-events-none"
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 0.15, 0.05, 0.12, 0] }}
                transition={{ duration: 1.5, times: [0, 0.2, 0.4, 0.6, 1] }}
                style={{ boxShadow: 'inset 0 0 40px 10px rgba(6,182,212,0.3)' }}
              />
            )}
          </div>

          {/* Buttons row */}
          <div className="hero-buttons absolute left-[14%] bottom-[5%] w-[13%] h-[16%] opacity-0 z-20">
            <HwButton label="Saat +" btnId={1} />
          </div>
          <div className="hero-buttons absolute left-[31%] bottom-[5%] w-[13%] h-[16%] opacity-0 z-20">
            <HwButton label="Saat -" btnId={2} />
          </div>
          <div className="hero-buttons absolute left-[56%] bottom-[5%] w-[13%] h-[16%] opacity-0 z-20">
            <HwButton label="Dak +" btnId={3} />
          </div>
          <div className="hero-buttons absolute left-[73%] bottom-[5%] w-[13%] h-[16%] opacity-0 z-20">
            <HwButton label="Dak -" btnId={4} />
          </div>
        </div>
      </div>
    </section>
  );
};
